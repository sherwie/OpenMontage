# Setup — do this on your Mac

## 1. Fork OpenMontage
On github.com, go to calesthio/OpenMontage and click "Fork" into your own
account. This gives you your own copy — the original repo is never touched.

## 2. Open Claude Code, point it at your fork
On your Mac, open Claude Code and tell it:
"Clone my fork of OpenMontage at github.com/<your-username>/OpenMontage and
run the setup steps in its README."
It will clone the repo and run `make setup` (Python, FFmpeg, Node install)
for you.

## 3. Drop in this kit
Copy this entire `channel-kit` folder's contents into your cloned repo:
- `CLAUDE.md` → repo root (this is the one file Claude Code reads automatically
  every session — if a CLAUDE.md already exists from OpenMontage, merge rather
  than overwrite, keeping OpenMontage's own operating notes intact)
- `skills/channel/` → repo's `skills/` folder
- `pipeline_defs/business-history-documentary.yaml` → repo's `pipeline_defs/`
- `docs/SETUP.md` → this file, keep for reference

Easiest way: tell Claude Code "I'm going to paste the contents of several
files — create each one at the path I give you," then paste each file from
this kit in turn.

## 4. Add API keys to .env
- `ELEVENLABS_API_KEY` — you already have this account
- `PEXELS_API_KEY`, `PIXABAY_API_KEY` — free, sign up takes a minute each
- Leave video-generation keys (Runway, fal.ai, etc.) empty for now — this
  channel runs real-footage-only by default per the pipeline manifest

## 5. Set the budget cap
In `.env` or wherever OpenMontage's budget config lives, set a conservative
cap (e.g. $10) while testing the first few episodes.

## 6. Run episode one
Tell Claude Code:
"Run the business_history_documentary pipeline for [your chosen company/topic].
Follow CLAUDE.md and stop at every gate for my approval."

It will run Trend Intelligence, then Content Strategy, then pause for your
approval before spending anything further — exactly the validation-first flow
from the original plan.

## What to expect the first time
The first episode will be slower than later ones — you're reviewing gates you
haven't seen before and calibrating what "good enough to approve" looks like.
That's expected and correct; don't rush it to get to a finished video faster.
